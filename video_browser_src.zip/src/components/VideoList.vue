<template>
  <ul>
    <VideoListItem v-for="myvideo in videos" :key="myvideo">
    </VideoListItem>

  </ul>
</template>

<script>
import VideoListItem from './VideoListItem';

  export default {
    name: 'VideoList',
    components: {
      VideoListItem
    },
    props: ['videos']
  };
</script>

<style>
</style>
